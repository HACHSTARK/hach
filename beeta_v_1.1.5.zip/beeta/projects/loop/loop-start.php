<?php
/**
 * Project Loop Start
 *
 * @author 		WooThemes
 * @package 	Projects/Templates
 * @version     1.0.0
 */
?>
<div id="projects_list">