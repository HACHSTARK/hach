25/Nov/2016: Released version 1.0
	-	You need read instruction in documentation folder
	